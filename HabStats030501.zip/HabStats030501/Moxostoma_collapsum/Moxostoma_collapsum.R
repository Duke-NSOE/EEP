#R log file for Moxostoma_collapsum; Created: 2015-08-27 21:24:43
setwd("C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum")
sppAll <- read.csv("Moxostoma_collapsum_SWD.csv")
spp <- sppAll[,c(1)]
sppBin = c(spp)
sppBin <- replace(sppBin, sppBin == 1, 0)
sppBin <- replace(sppBin, sppBin == 2, 1)
habData <- sppAll[c("Temp_max","cold","MeanShadeLength","NLCD5c","warm","Riparian_4P","LongestSegment","FLNLCD_1","Q0001E","RunOff_min","TempVC","Riparian_9P","FLNLCD_3","Riparian_8P","NLCD8","NLCD3c","FLNLCD_8","Riparian_3A","Q0001E_min","FLNLCD_7","Riparian_3P","Qincr0001E","upstreamDistance_km","Riparian_5A","FLNLCD_4","NLCD3","NLCD7","FLNLCD_9","Riparian_4A","NLCD5","AreaSqKM","Riparian_8A","cool","V0001E","StreamOrde")]
sppGLM <- glm(as.factor(spp)~., data=habData, family=binomial)
sppGLMAnova <- anova(sppGLM, test="Chi")
write.csv(sppGLMAnova, "C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum\\GLM_Anova.csv")
sppGLMd2 <- 1-(sppGLM$deviance/sppGLM$null.deviance)
sppPredGLM <- predict(sppGLM, type="response",data=habData)
library(ROCR)
source("C:\\Workspace\\EEP\\Scripts\\RScripts\\cutoff.ROCR.R")
sppPred <- prediction(sppGLM$fitted.values,spp)
cutoff <- cutoff.ROCR(sppPred, "tpr", target=0.95)
sppPredGLM[sppPredGLM < cutoff] <- 0
sppPredGLM[sppPredGLM >= cutoff] <- 1
cfGLM <- table(sppPredGLM,spp)
write.csv(cfGLM,"C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum\\GLM_Confusion.csv")
outTableGLM <- cbind(sppAll$X,sppGLM$fitted.values,sppPredGLM,sppBin)
colnames(outTableGLM)[0] <- "ID"
colnames(outTableGLM)[1] <- "GRIDCODE"
colnames(outTableGLM)[2] <- "HAB_PROB"
colnames(outTableGLM)[3] <- "PREDICTION"
colnames(outTableGLM)[4] <- "OBSERVED"
write.csv(outTable,"C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum\\GLM_Predictions.csv")
library(randomForest)
sppForest <- randomForest(as.factor(spp)~., data=habData, ntree=501, importance=TRUE)
outTableRFVars <- sppForest$importance
write.csv(outTableRFVars,"C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum\\RF_VarImportance.csv")
rfProbs <- predict(sppForest, type="prob")
rfPredictions <- predict(sppForest, type="response")
rfPredBin = c(rfPredictions)
rfPredBin <- replace(rfPredBin, rfPredBin == 1, 0)
rfPredBin <- replace(rfPredBin, rfPredBin == 2, 1)
outTableRF <- cbind(sppAll$X,rfProbs[,(2)],rfPredBin,sppBin)
colnames(outTableRF)[1] <- "GRIDCODE"
colnames(outTableRF)[2] <- "HABPROB"
colnames(outTableRF)[3] <- "PREDICTION"
colnames(outTableRF)[4] <- "OBSERVED"
write.csv(outTableRF,"C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum\\RF_Predictions.csv")
cfRF <- table(rfPredictions,spp)
write.csv(cfRF,"C:\\Workspace\\EEP\\HabStats030501\\Moxostoma_collapsum\\RF_Confusion.csv")
save.image()
