#R log file for Nocomis_leptocephalus; Created: 2015-08-17 09:34:18
setwd("D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus")
sppAll <- read.csv("Nocomis_leptocephalus_SWD.csv")
spp <- sppAll[,c(1)]
sppBin = c(spp)
sppBin <- replace(sppBin, sppBin == 1, 0)
sppBin <- replace(sppBin, sppBin == 2, 1)
habData <- sppAll[c("RunOff_min","MeanShadeLength","Riparian_9P","Riparian_3P","PctCanopy","Riparian_2P","NLCD3c","Riparian_3A","NLCD5c","TotDASqKM","NLCD9c","NLCD8c","FLNLCD_3","NLCD1c","cold","Temp_min","PPT0001","RunOffVMA","RunOff_max","Riparian_1P","NLCD3","Precip_min","Riparian_8P","downstreamDistance_km","FCODE","StreamOrde","FLNLCD_2","LongestSegment","Pathlength","TempVC","PrecipVC","Riparian_2A","FLNLCD_5","Riparian_9A","NPDES","cool","FLNLCD_7","FLNLCD_9","Qincr0001E","NLCD8","NLCD2","FLNLCD_8","Riparian_7A","Riparian_5A","V0001E","AreaSqKM","Riparian_4A","FLNLCD_4","NLCD5","Riparian_8A")]
sppGLM <- glm(as.factor(spp)~., data=habData, family=binomial)
sppGLMAnova <- anova(sppGLM, test="Chi")
write.csv(sppGLMAnova, "D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus\\GLM_Anova.csv")
sppGLMd2 <- 1-(sppGLM$deviance/sppGLM$null.deviance)
sppPredGLM <- predict(sppGLM, type="response",data=habData)
library(ROCR)
source("D:\\Workspace\\EEP\\Scripts\\RScripts\\cutoff.ROCR.R")
sppPred <- prediction(sppGLM$fitted.values,spp)
cutoff <- cutoff.ROCR(sppPred, "tpr", target=0.95)
sppPredGLM[sppPredGLM < cutoff] <- 0
sppPredGLM[sppPredGLM >= cutoff] <- 1
cfGLM <- table(sppPredGLM,spp)
write.csv(cfGLM,"D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus\\GLM_Confusion.csv")
outTableGLM <- cbind(sppAll$X,sppGLM$fitted.values,sppPredGLM,sppBin)
colnames(outTableGLM)[0] <- "ID"
colnames(outTableGLM)[1] <- "GRIDCODE"
colnames(outTableGLM)[2] <- "HAB_PROB"
colnames(outTableGLM)[3] <- "PREDICTION"
colnames(outTableGLM)[4] <- "OBSERVED"
write.csv(outTable,"D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus\\GLM_Predictions.csv")
library(randomForest)
sppForest <- randomForest(as.factor(spp)~., data=habData, ntree=501, importance=TRUE)
outTableRFVars <- sppForest$importance
write.csv(outTableRFVars,"D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus\\RF_VarImportance.csv")
rfProbs <- predict(sppForest, type="prob")
rfPredictions <- predict(sppForest, type="response")
rfPredBin = c(rfPredictions)
rfPredBin <- replace(rfPredBin, rfPredBin == 1, 0)
rfPredBin <- replace(rfPredBin, rfPredBin == 2, 1)
outTableRF <- cbind(sppAll$X,rfProbs[,(2)],rfPredBin,sppBin)
colnames(outTableRF)[1] <- "GRIDCODE"
colnames(outTableRF)[2] <- "HABPROB"
colnames(outTableRF)[3] <- "PREDICTION"
colnames(outTableRF)[4] <- "OBSERVED"
write.csv(outTableRF,"D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus\\RF_Predictions.csv")
cfRF <- table(sppPredGLM,spp)
write.csv(cfRF,"D:\\Workspace\\EEP\\HabStats030501\\Nocomis_leptocephalus\\RF_Confusion.csv")
save.image()
