#R log file for Lepomis_auritus; Created: 2015-08-17 09:35:24
setwd("D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus")
sppAll <- read.csv("Lepomis_auritus_SWD.csv")
spp <- sppAll[,c(1)]
sppBin = c(spp)
sppBin <- replace(sppBin, sppBin == 1, 0)
sppBin <- replace(sppBin, sppBin == 2, 1)
habData <- sppAll[c("NLCD3c","Temp_min","AnimalOps","Riparian_9P","Riparian_3P","NLCD5c","Precip_min","TotDASqKM","Riparian_3A","NLCD9c","PrecipVC","NLCD8c","Riparian_4P","warm","NLCD1c","MeanShadeLength","downstreamDistance_km","TempVC","LongestSegment","FLNLCD_3","Pathlength","Riparian_1P","PctImpervious","Riparian_2P","Riparian_8P","FCODE","NLCD3","FLNLCD_7","NLCD8","StreamOrde","FLNLCD_5","NLCD7","cool","Riparian_9A","Riparian_7A","FLNLCD_9","NPDES","FLNLCD_8","V0001E","Qincr0001E","Riparian_5A","FLNLCD_4","Riparian_4A","FLNLCD_2","AreaSqKM","Riparian_2A","Riparian_8A")]
sppGLM <- glm(as.factor(spp)~., data=habData, family=binomial)
sppGLMAnova <- anova(sppGLM, test="Chi")
write.csv(sppGLMAnova, "D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus\\GLM_Anova.csv")
sppGLMd2 <- 1-(sppGLM$deviance/sppGLM$null.deviance)
sppPredGLM <- predict(sppGLM, type="response",data=habData)
library(ROCR)
source("D:\\Workspace\\EEP\\Scripts\\RScripts\\cutoff.ROCR.R")
sppPred <- prediction(sppGLM$fitted.values,spp)
cutoff <- cutoff.ROCR(sppPred, "tpr", target=0.95)
sppPredGLM[sppPredGLM < cutoff] <- 0
sppPredGLM[sppPredGLM >= cutoff] <- 1
cfGLM <- table(sppPredGLM,spp)
write.csv(cfGLM,"D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus\\GLM_Confusion.csv")
outTableGLM <- cbind(sppAll$X,sppGLM$fitted.values,sppPredGLM,sppBin)
colnames(outTableGLM)[0] <- "ID"
colnames(outTableGLM)[1] <- "GRIDCODE"
colnames(outTableGLM)[2] <- "HAB_PROB"
colnames(outTableGLM)[3] <- "PREDICTION"
colnames(outTableGLM)[4] <- "OBSERVED"
write.csv(outTable,"D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus\\GLM_Predictions.csv")
library(randomForest)
sppForest <- randomForest(as.factor(spp)~., data=habData, ntree=501, importance=TRUE)
outTableRFVars <- sppForest$importance
write.csv(outTableRFVars,"D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus\\RF_VarImportance.csv")
rfProbs <- predict(sppForest, type="prob")
rfPredictions <- predict(sppForest, type="response")
rfPredBin = c(rfPredictions)
rfPredBin <- replace(rfPredBin, rfPredBin == 1, 0)
rfPredBin <- replace(rfPredBin, rfPredBin == 2, 1)
outTableRF <- cbind(sppAll$X,rfProbs[,(2)],rfPredBin,sppBin)
colnames(outTableRF)[1] <- "GRIDCODE"
colnames(outTableRF)[2] <- "HABPROB"
colnames(outTableRF)[3] <- "PREDICTION"
colnames(outTableRF)[4] <- "OBSERVED"
write.csv(outTableRF,"D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus\\RF_Predictions.csv")
cfRF <- table(sppPredGLM,spp)
write.csv(cfRF,"D:\\Workspace\\EEP\\HabStats030501\\Lepomis_auritus\\RF_Confusion.csv")
save.image()
