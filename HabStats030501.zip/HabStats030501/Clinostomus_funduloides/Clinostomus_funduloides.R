#R log file for Clinostomus_funduloides; Created: 2015-08-17 09:35:58
setwd("D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides")
sppAll <- read.csv("Clinostomus_funduloides_SWD.csv")
spp <- sppAll[,c(1)]
sppBin = c(spp)
sppBin <- replace(sppBin, sppBin == 1, 0)
sppBin <- replace(sppBin, sppBin == 2, 1)
habData <- sppAll[c("PPT0001","Q0001E_min","Q0001E","Q0001E_max","PrecipVC","downstreamDistance_km","FLNLCD_1","Precip_min","RunOff_max","NLCD2c","ArbolateSu","Riparian_8P","NLCD4c","NLCD7c","NLCD9c","RunOffVMA","FLNLCD_2","NLCD2","PctCanopy","cool","NLCD8","Riparian_2A","NLCD3","NLCD9","FLNLCD_9","Riparian_1P","FCODE","V0001E","NLCD7","Qincr0001E","cold","TEMP0001","TempVC","Temp_min","FLNLCD_8","FLNLCD_5","FLNLCD_7","Riparian_5A","AreaSqKM","LongestSegment","Riparian_8A","NLCD4","FLNLCD_4")]
sppGLM <- glm(as.factor(spp)~., data=habData, family=binomial)
sppGLMAnova <- anova(sppGLM, test="Chi")
write.csv(sppGLMAnova, "D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides\\GLM_Anova.csv")
sppGLMd2 <- 1-(sppGLM$deviance/sppGLM$null.deviance)
sppPredGLM <- predict(sppGLM, type="response",data=habData)
library(ROCR)
source("D:\\Workspace\\EEP\\Scripts\\RScripts\\cutoff.ROCR.R")
sppPred <- prediction(sppGLM$fitted.values,spp)
cutoff <- cutoff.ROCR(sppPred, "tpr", target=0.95)
sppPredGLM[sppPredGLM < cutoff] <- 0
sppPredGLM[sppPredGLM >= cutoff] <- 1
cfGLM <- table(sppPredGLM,spp)
write.csv(cfGLM,"D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides\\GLM_Confusion.csv")
outTableGLM <- cbind(sppAll$X,sppGLM$fitted.values,sppPredGLM,sppBin)
colnames(outTableGLM)[0] <- "ID"
colnames(outTableGLM)[1] <- "GRIDCODE"
colnames(outTableGLM)[2] <- "HAB_PROB"
colnames(outTableGLM)[3] <- "PREDICTION"
colnames(outTableGLM)[4] <- "OBSERVED"
write.csv(outTable,"D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides\\GLM_Predictions.csv")
library(randomForest)
sppForest <- randomForest(as.factor(spp)~., data=habData, ntree=501, importance=TRUE)
outTableRFVars <- sppForest$importance
write.csv(outTableRFVars,"D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides\\RF_VarImportance.csv")
rfProbs <- predict(sppForest, type="prob")
rfPredictions <- predict(sppForest, type="response")
rfPredBin = c(rfPredictions)
rfPredBin <- replace(rfPredBin, rfPredBin == 1, 0)
rfPredBin <- replace(rfPredBin, rfPredBin == 2, 1)
outTableRF <- cbind(sppAll$X,rfProbs[,(2)],rfPredBin,sppBin)
colnames(outTableRF)[1] <- "GRIDCODE"
colnames(outTableRF)[2] <- "HABPROB"
colnames(outTableRF)[3] <- "PREDICTION"
colnames(outTableRF)[4] <- "OBSERVED"
write.csv(outTableRF,"D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides\\RF_Predictions.csv")
cfRF <- table(sppPredGLM,spp)
write.csv(cfRF,"D:\\Workspace\\EEP\\HabStats030501\\Clinostomus_funduloides\\RF_Confusion.csv")
save.image()
